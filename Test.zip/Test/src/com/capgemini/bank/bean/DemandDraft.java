package com.capgemini.bank.bean;

import java.util.Date;

public class DemandDraft {
	private int trans_id;	
	private String name;
		private String ph_no;
		private String favor;
		//private String date;
		private double amt;
		private double comm;
		private String remarks;
		Date tran_dt;
	
		public int getTrans_id() {
			return trans_id;
		}
		
		public void setTrans_id(int trans_id) {
			this.trans_id = trans_id;
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getPh_no() {
			return ph_no;
		}
		
		public void setPh_no(String ph_no) {
			this.ph_no = ph_no;
		}
		
		public String getFavor() {
			return favor;
		}
		
		public void setFavor(String favor) {
			this.favor = favor;
		}
		
	public Date getTran_dt() {
		return tran_dt;
	}
	
	public void setTran_dt(Date tran_dt) {
		this.tran_dt = tran_dt;
	}
		
		public double getAmt() {
			return amt;
		}
		
		public void setAmt(double amt) {
			this.amt = amt;
		}
		
		public double getComm() {
			return comm;
		}
		
		public void setComm(double comm) {
			this.comm = comm;
		}
		
		public String getRemarks() {
			return remarks;
		}
		
		public void setRemarks(String remarks) {
			this.remarks = remarks;
		}

}
