package com.capgemini.bank.ui;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.dao.*;
import java.sql.SQLException;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) throws SQLException {
		IDemandDraftService dds= new DemandDraftService();
		IDemandDraftDAO ddo= new DemandDraftDAO();
		double comm;
		DemandDraft dd = new DemandDraft();
		Scanner sc= new Scanner(System.in);
		while(true){
		System.out.println("Enter your choice- ");
		System.out.println("1. Enter the Demand Draft details- ");
		System.out.println("2. Print the Demand Draft details- ");
		System.out.println("3. Exit- ");
		int ch= sc.nextInt();
		
		switch(ch)
		{
		
		
case 1: System.out.println("Enter the Customer name- ");
		String name=sc.next();
		dd.setName(name);
		
		System.out.println("Enter the Customer ph_no- ");
		String ph_no=sc.next();
		dd.setPh_no(ph_no);
		
		System.out.println("In favour of- ");
		String favor=sc.next();
		dd.setFavor(favor);
		
		System.out.println("Enter the DD amount- ");
		double amt=sc.nextDouble();
		dd.setAmt(amt);
		
	if(amt<=500){
		comm=10;
		dd.setComm(comm);}
	
	else if(amt>=5001 && amt<=10000){
		comm=41;
		dd.setComm(comm);
	}
	else if(amt>=10001 && amt<=100000){
		comm=51;
		dd.setComm(comm);
	}
	else if(amt>=100001 && amt<=500000){
		comm=51;
		dd.setComm(comm);}
		System.out.println("Enter the remarks- ");
		String remarks=sc.next();
		dd.setRemarks(remarks);
	if(dds.isValidate(dd))	
		{
		int i= ddo.addDemandDraftDetails(dd);
		
		if(i==1)
			System.out.println("Details entered");
		else 
		
			System.out.println(" Error");
		}
	else 
		System.out.println("Enter the details properly");
		break;
	case 2: System.out.println("Enter the transaction id to search- ");
				int tid= sc.nextInt();
				ddo.getDemandDraftDetails(tid);
			
				System.out.println("Name of the bank: XYZ");
				System.out.println("DD Amount= "+dd.getAmt());
				System.out.println("DD Commission= "+dd.getComm());
				double total= dd.getAmt()+dd.getComm();
				System.out.println("Total Amount= "+total);
				System.out.println("Remarks= "+dd.getRemarks());
	break;
	
case 3: System.exit(0);
				break;
default: System.out.println(" Enter a valid choice");				
		
		}
		}
	}

}
