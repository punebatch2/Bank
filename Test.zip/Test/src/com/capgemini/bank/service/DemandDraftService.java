package com.capgemini.bank.service;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.utils.DBUtils;


public class DemandDraftService implements IDemandDraftService{
	DemandDraft dd1;
	IDemandDraftDAO dd=new DemandDraftDAO();
	private Connection dbConnection; // ???

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	


	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		// TODO Auto-generated method stub
	//	dd.addDemandDraftDetails(demandDraft);
		
		return 0;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionid) throws SQLException {
		// TODO Auto-generated method stub
		
		return null;
	}

	@Override
	public boolean isValidate(DemandDraft demandDraft) {
		// TODO Auto-generated method stub
		String p=demandDraft.getPh_no();
		if(p.length()==10)
		return true;
		return false;
	}
	
/*	private int transactionId() throws SQLException {
		int id = 0;

		String selectQuery = "select TRANSACTION_ID_SEQ.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
		return id;
	}
	
	*/
	
	

	
}
