package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.utils.DBUtils;

public class DemandDraftDAO implements IDemandDraftDAO {

DemandDraft dd=new DemandDraft();
	
	private Connection dbConnection; // ???

	{
		try {
			dbConnection = DBUtils.getConnection();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private int transactionId() throws SQLException {
		int id = 0;

		String selectQuery = "select TRANSACTION_ID_SEQ.nextval from dual";

		Statement selectStatement = dbConnection.createStatement();
		ResultSet result = selectStatement.executeQuery(selectQuery);

		result.next();

		id = result.getInt(1);
		return id;
	}
	
	
	
	

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws SQLException {
		// TODO Auto-generated method stub
		String insertQuery = "insert into DEMAND_DRAFT values(?,?,?,?,?,?,?,?)";
		PreparedStatement insertStatement = dbConnection.prepareStatement(insertQuery);
				
		insertStatement.setInt(1, transactionId());
		insertStatement.setString(2, demandDraft.getName());
		insertStatement.setString(3, demandDraft.getFavor());
		insertStatement.setString(4, demandDraft.getPh_no());
		insertStatement.setDate(5, (Date) demandDraft.getTran_dt());
		insertStatement.setDouble(6, demandDraft.getAmt());
		insertStatement.setDouble(7, demandDraft.getComm());
		insertStatement.setString(8, demandDraft.getRemarks());
		

		
		int rows = insertStatement.executeUpdate();
		
		if(rows > 0)
			return 1;
		
		
		return 0;
		
	
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionid) throws SQLException {
		// TODO Auto-generated method stub
		String selectQuery = "select * from DEMAND_DRAFT where TRANSACTION_ID = ?";
		PreparedStatement selectStatement = dbConnection.prepareStatement(selectQuery);

		selectStatement.setInt(1, transactionid);

		ResultSet result = selectStatement.executeQuery();

		while (result.next()) {

			int transid = result.getInt(1);
			dd.setTrans_id(transid);
			String n= result.getString(2);
				dd.setName(n);
				String f= result.getString(3);
				dd.setName(f);
				String ph= result.getString(4);
				dd.setName(ph);
				double a= result.getDouble(6);
				dd.setAmt(a);
				double c= result.getDouble(7);
				dd.setComm(c);
				String r= result.getString(8);
				dd.setRemarks(r);
		
	
	}
		return dd;
}
}
	
